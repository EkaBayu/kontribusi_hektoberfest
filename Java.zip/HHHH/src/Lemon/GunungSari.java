/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lemon;

/**
 *
 * @author Adiand An
 */
public class GunungSari {
public static void main(String[] args) {
for( int nilaiAwal = 5; nilaiAwal >= 1; nilaiAwal-- ){
    System.out.println(nilaiAwal);
}
        
	
}
    
}
